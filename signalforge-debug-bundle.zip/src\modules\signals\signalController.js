import { readJson, sendError, sendJson } from "../../shared/http.js";
import { detectMatchingAlerts } from "../alerts/alertService.js";
import { enqueueMatchingTelegramNotifications } from "../notifications/notificationService.js";
import {
  createSignal,
  cancelScanAllJob,
  getScanAllJobStatus,
  listUserSignals,
  scanAllMarkets,
  scanMarketSetup,
  startScanAllJob,
  unlockTelegramSignal
} from "./signalService.js";
import { getCandidateQualitySummary, listSetupCandidates } from "./setupCandidateService.js";
import { getLatestDailyMarketBrief } from "./dailyMarketBriefService.js";

// scanMarketSetupDetailed stays service-private so Telegram receives full setups
// without exposing locked price levels in scan responses.

export async function handleSignalRoutes(req, res, pathname) {
  if (!pathname.startsWith("/api/signals")) {
    return false;
  }

  if (!req.user) {
    return sendError(res, 401, "Authentication required.");
  }

  if (pathname === "/api/signals" && req.method === "GET") {
    return sendJson(res, 200, await listUserSignals(req.user));
  }

  if (pathname === "/api/signals/candidates" && req.method === "GET") {
    return sendJson(res, 200, { candidates: await listSetupCandidates() });
  }

  if (pathname === "/api/signals/market-brief" && req.method === "GET") {
    return sendJson(res, 200, { marketBrief: await getLatestDailyMarketBrief() });
  }

  if (pathname === "/api/signals/candidates/quality" && req.method === "GET") {
    if (!req.user.isAdmin) return sendError(res, 403, "Admin access required.");
    const [quality, marketBrief] = await Promise.all([
      getCandidateQualitySummary(),
      getLatestDailyMarketBrief()
    ]);
    return sendJson(res, 200, { quality, marketBrief });
  }

  if (pathname === "/api/signals/scan" && req.method === "POST") {
    try {
      const body = await readJson(req);
      return sendJson(res, 200, await scanMarketSetup(req.user, body));
    } catch (error) {
      return sendError(res, error.statusCode || 400, error.message, {
        subscription: error.subscription
      });
    }
  }

  if (pathname === "/api/signals/scan-all/start" && req.method === "POST") {
    try {
      const body = await readJson(req).catch(() => ({}));
      const result = await startScanAllJob(req.user, body, {
        onComplete: async (scanResult) => {
          const detectedAlerts = await detectMatchingAlerts(req.user, scanResult.setups);
          const queuedTelegramAlerts = await enqueueMatchingTelegramNotifications(
            req.user,
            scanResult.fullSetups
          );
          return {
            detectedAlerts,
            queuedTelegramAlerts: queuedTelegramAlerts.length
          };
        }
      });
      return sendJson(res, 202, result);
    } catch (error) {
      return sendError(res, error.statusCode || 400, error.message, {
        subscription: error.subscription
      });
    }
  }

  if (pathname === "/api/signals/scan-all/status" && req.method === "GET") {
    try {
      const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
      return sendJson(res, 200, getScanAllJobStatus(req.user, url.searchParams.get("jobId")));
    } catch (error) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  if (pathname === "/api/signals/scan-all/cancel" && req.method === "POST") {
    try {
      const body = await readJson(req).catch(() => ({}));
      return sendJson(res, 200, cancelScanAllJob(req.user, body.jobId));
    } catch (error) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  if (pathname === "/api/signals/scan-all" && req.method === "POST") {
    try {
      const body = await readJson(req).catch(() => ({}));
      const result = await scanAllMarkets(req.user, body);
      const detectedAlerts = await detectMatchingAlerts(req.user, result.setups);
      const queuedTelegramAlerts = await enqueueMatchingTelegramNotifications(
        req.user,
        result.fullSetups
      );
      const { fullSetups, ...publicResult } = result;
      return sendJson(res, 200, {
        ...publicResult,
        detectedAlerts,
        queuedTelegramAlerts: queuedTelegramAlerts.length
      });
    } catch (error) {
      return sendError(res, error.statusCode || 400, error.message, {
        subscription: error.subscription
      });
    }
  }

  if (pathname === "/api/signals/generate" && req.method === "POST") {
    try {
      const body = await readJson(req);
      const result = await createSignal(req.user, body);
      return sendJson(res, result.signal && !result.alreadyUnlocked ? 201 : 200, result);
    } catch (error) {
      return sendError(res, error.statusCode || 400, error.message, {
        subscription: error.subscription
      });
    }
  }

  if (pathname === "/api/signals/telegram-unlock" && req.method === "POST") {
    try {
      const body = await readJson(req);
      const result = await unlockTelegramSignal(req.user, body);
      return sendJson(res, result.signal && !result.alreadyUnlocked ? 201 : 200, result);
    } catch (error) {
      return sendError(res, error.statusCode || 400, error.message, {
        subscription: error.subscription
      });
    }
  }

  return false;
}
